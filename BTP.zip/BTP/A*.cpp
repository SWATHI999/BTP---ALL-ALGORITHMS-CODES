#include<stdio.h>
#include<iostream>
#include<queue>
using namespace std;
struct node
{
	int vertex_number=0,f=0,g=0;

};
struct myCompare_f
{
	bool operator()(struct node x,struct node y)
	{
		return x.f>y.f;
	}
};
class Astar
{
	int G[1000][1000],source,goal,vertexcount,set[1000],heuristics[1000],parent[1000];
	priority_queue<struct node,vector<struct node>,myCompare_f>openq;
	queue <struct node> closedq;
	public:
	int checkopen(int v);
	int checkclosed(int v);
	void init(int n);
	int* neighbours(int v);
	int degree(int v);
	int astar(int s,int g);
	void update(int child,int vertex,int score);
	void printpath(int s,int t);

};
void Astar::init(int n)
{
	vertexcount=n;
	printf("Enter the adjacency matrix\n");
	for(int i=1;i<=vertexcount;i++)
	{
		parent[i]=0;
		for(int j=1;j<=vertexcount;j++)
		{

			scanf("%d",&G[i][j]);

		}
	}


	printf("Enter the Heuristics matrix\n");
	for(int j=1;j<=vertexcount;j++)
	{

		scanf("%d",&heuristics[j]);

	}

}
int* Astar::neighbours(int v)
{
	int k=1;
	for(int i=1;i<=vertexcount;i++)
	{
		if(G[v][i]>0)
		{
			set[k]=i;
			k++;
		}
	}
	return set;
}
int Astar::degree(int v)
{
	int d=0;
	for(int i=1;i<=vertexcount;i++)
	{
		if(G[v][i]>0)
			d++;
	}
	return d;
}
int Astar::checkclosed(int v)
{
	int flag=0;
	queue <struct node> copyclosedq;
	copyclosedq=closedq;
	while(copyclosedq.size()>0)
	{
		node temp;
		temp=copyclosedq.front();
		if(temp.vertex_number==v)
		{
			flag=1;
			break;
		}
		copyclosedq.pop();
	}
	if(flag==1)
		return 1;
	else
		return 0;
}
int Astar::checkopen(int v)
{
	int flag=0;
	priority_queue<struct node,vector<struct node>,myCompare_f>copyopenq;
	node temp;
	copyopenq=openq;
	while(copyopenq.size()>0)
	{

		temp=copyopenq.top();
		if(temp.vertex_number==v)
		{
			flag=1;
			break;
		}
		copyopenq.pop();
	}
	if(flag==1)
		return temp.g;
	else
		return 0;
}
void Astar::update(int child,int vertex,int score)
{
	priority_queue<struct node,vector<struct node>,myCompare_f>copyopenq;
	while(openq.size()>0)
	{
		node x=openq.top();
		if(x.vertex_number==child)
		{

			x.vertex_number=child;
			x.g=score;
			parent[x.vertex_number]=vertex;
			x.f=x.g+heuristics[x.vertex_number];
			copyopenq.push(x);
		}
		else
		{
			copyopenq.push(x);
		}
		openq.pop();
	}
	openq=copyopenq;

}
int Astar::astar(int s,int g)
{
	source=s;
	goal=g;
	node temp;
	temp.vertex_number=s;
	temp.g=0;
	temp.f=temp.g+heuristics[s];
	parent[temp.vertex_number]=-1;
	openq.push(temp);
	while(openq.size()>0)
	{
		node fmin=openq.top();
		if(fmin.vertex_number==goal)
		{
			printf("u:%d\n",fmin.g);
			printpath(source,goal);
		}
		openq.pop();
		closedq.push(fmin);
		int* nei=neighbours(fmin.vertex_number);
		for(int i=1;i<=degree(fmin.vertex_number);i++)
		{
			int belong_closed=checkclosed(nei[i]);
			if(belong_closed==1)
			{

				continue;
			}		
			int notbelong_open=checkopen(nei[i]);
			if(notbelong_open==0)
			{
				temp.vertex_number=nei[i];
				temp.g=fmin.g+G[fmin.vertex_number][nei[i]];
				temp.f=temp.g+heuristics[nei[i]];
				parent[nei[i]]=fmin.vertex_number;
				openq.push(temp);
			}
			else
			{

				int tempg=fmin.g+G[fmin.vertex_number][nei[i]];
				if(tempg>=notbelong_open)
					continue;
				else
				{

					update(nei[i],fmin.vertex_number,tempg);

				}
			}

		}


	}

}



void Astar::printpath(int s,int t)
{
	int k;
	if(t==s)
	{
		printf("%d",t);
		return;
	}
	else
	{
		k=parent[t];
		printpath(s,k);
		printf("%c",' ');
		printf("%d",t);

	}
}
int main()
{
	Astar a;
	int n,s,g;
	printf("Enter the number of nodes\n");
	scanf("%d",&n);
	printf("Enter the source node\n");
	scanf("%d",&s);
	printf("Enter the destination node\n");
	scanf("%d",&g);
	a.init(n);
	a.astar(s,g);
	
}
