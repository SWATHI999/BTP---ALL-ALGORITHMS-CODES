#include<stdio.h>
#include<iostream>
#include<queue>
using namespace std;
struct node
{
	int vertex_number=0,edge_cost=0;

};
struct myCompare_edge_cost
{
	bool operator()(struct node x,struct node y)
	{
		return x.edge_cost<y.edge_cost;
	}
};
class UCS
{
	int G[1000][1000],source,goal,vertexcount,set[1000],parent[1000];
	priority_queue<struct node,vector<struct node>,myCompare_edge_cost>openq;
	queue <struct node> closedq;
	public:
	void init(int n);
	int* neighbours(int v);
	int degree(int v);
	void ucs(int s,int g);
	void printpath(int s,int t);

};
void UCS::init(int n)
{
	vertexcount=n;
	printf("Enter the adjacency matrix\n");
	for(int i=1;i<=vertexcount;i++)
	{
		parent[i]=0;
		for(int j=1;j<=vertexcount;j++)
		{

			scanf("%d",&G[i][j]);

		}
	}
}
int* UCS::neighbours(int v)
{
	int k=1;
	for(int i=1;i<=vertexcount;i++)
	{
		if(G[v][i]>0)
		{
			set[k]=i;
			k++;
		}
	}
	return set;
}
int UCS::degree(int v)
{
	int d=0;
	for(int i=1;i<=vertexcount;i++)
	{
		if(G[v][i]>0)
			d++;
	}
	return d;
}
void UCS::ucs(int s,int g)
{
source=s;
goal=g;
node temp;
temp.vertex_number=s;
temp.edge_cost=0;
openq.push(temp);
while(openq.size()>0)
{
node x=openq.top();
if(x.vertex_number==goal)
exit(0);
else
{
openq.pop();
closedq.push(x);
}
int* set1=neighbours(x.vertex_number);
for(int k=1;k<=degree(x.vertex_number);k++)
{

}
}
void UCS::printpath(int s,int t)
{
	int k;
	if(t==s)
	{
		printf("%d",t);
		return;
	}
	else
	{
		k=parent[t];
		printpath(s,k);
		printf("%c",' ');
		printf("%d",t);

	}
}
int main()
{
	UCS u;
	int n,s,g;
	printf("Enter the number of nodes\n");
	scanf("%d",&n);
	printf("Enter the source node\n");
	scanf("%d",&s);
	printf("Enter the destination node\n");
	scanf("%d",&g);
	u.init(n);
	

}
