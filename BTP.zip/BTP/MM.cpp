#include<stdio.h>
#include<math.h>
#include<iostream>
#include<queue>
#include <stdlib.h>
#define MAX 99999
using namespace std;
struct node
{
	int vertex_number=0,f=0,g=0,priority=0;

};
struct myCompare_priority
{
	bool operator()(struct node x,struct node y)
	{
		return x.priority>y.priority;
	}
};

class MM
{
	int G[1000][1000],source,goal,vertexcount,set[1000],parent[1000],heuristics[1000],epsilon=MAX;
	priority_queue<struct node,vector<struct node>,myCompare_priority>qf;
	priority_queue<struct node,vector<struct node>,myCompare_priority>qb;

	int belong_result[2];
	int belong_result_back[2];
	queue <struct node> cqf;
	queue <struct node> cqb;

	public:
	int* check_backward(int v,priority_queue<struct node,vector<struct node>,myCompare_priority>open_queue);
	int* check_belong(int v,priority_queue<struct node,vector<struct node>,myCompare_priority>open_queue,queue<struct node>closed_queue);
	void init(int n);
	int meet_in_the_middle(int s,int g);
	int* neighbours(int v);
	int degree(int v);
	int calculate_max(node v);
	void checkdelete(int status,int vertex,priority_queue<struct node,vector<struct node>,myCompare_priority>open_queue,queue<struct node>closed_queue);


};



int* MM::check_backward(int v,priority_queue<struct node,vector<struct node>,myCompare_priority>open_queue)
{

	int flag=0;
	priority_queue<struct node,vector<struct node>,myCompare_priority>copy_open_queue;
	copy_open_queue=open_queue;
	node temp;
	while(copy_open_queue.size()>0)
	{
		temp=copy_open_queue.top();

		if(v==temp.vertex_number)
		{
			flag=1;
			break;
		}

		copy_open_queue.pop();

	}
	if(flag==1)
	{

		belong_result_back[1]=1;
		belong_result_back[2]=temp.g;
		return belong_result_back;
	}
	else
	{

		belong_result_back[1]=MAX;
		belong_result_back[2]=MAX;
		return belong_result_back;

	}

}
void MM::checkdelete(int status,int vertex,priority_queue<struct node,vector<struct node>,myCompare_priority>open_queue,queue<struct node>closed_queue)
{

	if(status==1)
	{
		priority_queue<struct node,vector<struct node>,myCompare_priority>copy_open_queue;
		while(open_queue.size()>0)
		{
			node temp=open_queue.top();

			if(vertex!=temp.vertex_number)
				copy_open_queue.push(temp);
			open_queue.pop();

		}
		open_queue=copy_open_queue;

	}
	else
	{
		queue <struct node>copy_closed_queue;
		while(closed_queue.size()>0)
		{
			node temp=closed_queue.front();

			if(vertex!=temp.vertex_number)
				copy_closed_queue.push(temp);

			closed_queue.pop();
		}
		closed_queue=copy_closed_queue;

	}
}
int MM::calculate_max(node v)
{


	int m1,m2,m3,fminf=MAX,fminb=MAX,gminf=MAX,gminb=MAX;
	priority_queue<struct node,vector<struct node>,myCompare_priority>qf1;
	priority_queue<struct node,vector<struct node>,myCompare_priority>qb1;
	qf1=qf;
	qb1=qb;

	while(qf1.size()>0)
	{
		node temp=qf1.top();
		if(fminf>temp.f)
			fminf=temp.f;
		if(gminf>temp.g)
			gminf=temp.g;
		qf1.pop();
	}
	while(qb1.size()>0)
	{
		node temp=qb1.top();
		if(fminb>temp.f)
			fminb=temp.f;
		if(gminb>temp.g)
			gminb=temp.g;
		qb1.pop();
	}

	m1=fmax(v.priority,fminf);
	m2=fmax(fminb,(gminf+gminb+epsilon));
	m3=fmax(m1,m2);
	return m3;
}
void MM::init(int n)
{
	vertexcount=n;
	printf("Enter the adjacency matrix\n");
	for(int i=1;i<=vertexcount;i++)
	{
		parent[i]=0;
		for(int j=1;j<=vertexcount;j++)
		{

			scanf("%d",&G[i][j]);

		}
	}

	printf("Enter the Heuristics matrix\n");
	for(int j=1;j<=vertexcount;j++)
	{

		scanf("%d",&heuristics[j]);

	}
	for(int i=1;i<=vertexcount;i++)
	{

		for(int j=1;j<=vertexcount;j++)
		{

			if(G[i][j]>0 && epsilon>=G[i][j])
				epsilon=G[i][j];

		}
	}


}

int* MM::neighbours(int v)
{
	int k=1;
	for(int i=1;i<=vertexcount;i++)
	{
		if(G[v][i]>0)
		{
			set[k]=i;
			k++;
		}
	}
	return set;
}
int MM::degree(int v)
{
	int d=0;
	for(int i=1;i<=vertexcount;i++)
	{
		if(G[v][i]>0)
			d++;
	}
	return d;
}
int* MM::check_belong(int v,priority_queue<struct node,vector<struct node>,myCompare_priority>open_queue,queue<struct node>closed_queue)
{
	int flag=0;
	priority_queue<struct node,vector<struct node>,myCompare_priority>copy_open_queue;
	queue<struct node>copy_closed_queue;
	copy_open_queue=open_queue;
	copy_closed_queue=closed_queue;
	while(copy_open_queue.size()>0)
	{
		node temp=copy_open_queue.top();
		if(temp.vertex_number==v)
		{
			belong_result[1]=1;
			belong_result[2]=temp.g;
			flag=1;
			break;
		}
		copy_open_queue.pop();
	}
	while(copy_closed_queue.size()>0)
	{
		node temp=copy_closed_queue.front();
		if(temp.vertex_number==v)
		{
			belong_result[1]=0;
			belong_result[2]=temp.g;
			flag=2;
			break;
		}
		copy_closed_queue.pop();
	}
	if(flag==1 || flag==2)
		return belong_result;
	else
	{
		belong_result[1]=MAX;
		belong_result[2]=MAX;
		return belong_result;
	}


}
int MM::meet_in_the_middle(int s,int g)
{
	int count=0;
	node c;
	int u=MAX,flag=0;
	source=s;
	goal=g;
	node temp;
	//forward
	temp.vertex_number=s;
	parent[s]=-1;
	temp.g=0;
	temp.f=temp.g+heuristics[s];
	temp.priority=max(temp.f,2*(temp.g));
	qf.push(temp);
	//backward
	temp.vertex_number=g;
	parent[g]=-1;
	temp.g=0;
	temp.f=temp.g+heuristics[g];
	temp.priority=max(temp.f,2*(temp.g));
	qb.push(temp);
	while(qf.size()>0 && qb.size()>0 )
	{
		count=count+1;
		node prminf,prminb;
		prminf=qf.top();
		prminb=qb.top();
		if(prminf.priority<prminb.priority)
		{

			c=prminf;
		}
		else
		{
			c=prminb;
		}
		int max_result=calculate_max(c);
		if(u<=max_result)
		{
			printf("Optimal Path Cost:%d\n",u);

			exit(0);
		}


		if(c.priority==prminf.priority)
		{
			cqf.push(c);
			qf.pop();

			int* neighbour_set=neighbours(c.vertex_number);
			for(int h=1;h<=degree(c.vertex_number);h++)
				for(int i=1;i<=degree(c.vertex_number);i++)
				{
					int* belong=check_belong(neighbour_set[i],qf,cqf);
					if(belong[1]!=MAX && belong[2]<=c.g+G[c.vertex_number][neighbour_set[i]])
					{
						continue;
					}
					if(belong[1]!=MAX)
					{
						checkdelete(belong[1],neighbour_set[i],qf,cqf);
					}

					node child;
					child.vertex_number=neighbour_set[i];
					parent[child.vertex_number]=c.vertex_number;
					child.g=c.g+G[c.vertex_number][neighbour_set[i]];
					child.f=child.g+heuristics[neighbour_set[i]];
					child.priority=fmax(child.f,2*child.g);
					qf.push(child);
					int* belong_back=check_backward(neighbour_set[i],qb);
					if(belong_back[1]!=MAX)
					{
						u=fmin(u,child.g+belong_back[2]);
					}
				}

		}
		else
		{
			qb.pop();
			cqb.push(c);

			int* neighbour_set=neighbours(c.vertex_number);
			for(int i=1;i<=degree(c.vertex_number);i++)
			{
				int* belong=check_belong(neighbour_set[i],qb,cqb);

				if(belong[1]!=MAX && belong[2]<=c.g+G[c.vertex_number][neighbour_set[i]])
				{
					continue;
				}				if(belong[1]!=MAX)
				{
					checkdelete(belong[1],neighbour_set[i],qb,cqb);
				}
				node child;
				child.vertex_number=neighbour_set[i];
				parent[child.vertex_number]=c.vertex_number;
				child.g=c.g+G[c.vertex_number][neighbour_set[i]];
				child.f=child.g+heuristics[neighbour_set[i]];
				child.priority=fmax(child.f,2*child.g);
				qb.push(child);
				int* belong_back=check_backward(neighbour_set[i],qf);
				if(belong_back[1]!=MAX)
				{
					u=fmin(u,child.g+belong_back[2]);
				}

			}	
		}
	}
}
int main()
{
	MM m;
	int n,s,g;
	printf("Enter the number of nodes\n");
	scanf("%d",&n);
	printf("Enter the source node\n");
	scanf("%d",&s);
	printf("Enter the destination node\n");
	scanf("%d",&g);
	m.init(n);
	m.meet_in_the_middle(s,g);

}

